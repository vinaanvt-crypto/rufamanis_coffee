document.addEventListener('DOMContentLoaded', () => {
  const navItems = document.querySelectorAll('.nav-menu a');
  const sections = document.querySelectorAll('.page-section');

  // Tampilkan halaman pertama
  const initialSection = document.querySelector(navItems[0].getAttribute('href'));
  if (initialSection) initialSection.classList.add('active');

  // Navigasi antar halaman
  navItems.forEach(item => {
    item.addEventListener('click', (e) => {
      e.preventDefault();
      const targetId = item.getAttribute('href');

      navItems.forEach(nav => nav.classList.remove('active'));  
      sections.forEach(sec => sec.classList.remove('active'));  

      item.classList.add('active');  
      const targetSection = document.querySelector(targetId);  
      if (targetSection) targetSection.classList.add('active');  

      // Tutup navbar collapse
      const navCollapse = document.querySelector('.navbar-collapse');  
      if (navCollapse.classList.contains('show')) {  
        new bootstrap.Collapse(navCollapse).toggle();  
      }  
    });
  });

  // Animasi About
  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('animate-show');
      }
    });
  }, { threshold: 0.3 });

// Animasi muncul saat scroll (untuk galeri)
const galeriItems = document.querySelectorAll('.galeri-item');

const showOnScroll = () => {
  const triggerBottom = window.innerHeight * 0.9;

  galeriItems.forEach(item => {
    const itemTop = item.getBoundingClientRect().top;
    if (itemTop < triggerBottom) {
      item.classList.add('show');
    }
  });
};

window.addEventListener('scroll', showOnScroll);
window.addEventListener('load', showOnScroll);

  document.querySelectorAll('.animate-left, .animate-right').forEach(el => observer.observe(el));
});

